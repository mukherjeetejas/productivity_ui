import React, { useEffect, useState } from "react";
import Layout from "../components/layout/Layout";
import {
  getDashboard,
  getTodayTimecard,
} from "../services/api";

const USER_ID = "tejasMukherjee";

export default function Dashboard() {
  const [dashboard, setDashboard] = useState(null);
  const [todayCard, setTodayCard] = useState(null);

  useEffect(() => {
    async function loadData() {
      const dash = await getDashboard(USER_ID);
      const today = await getTodayTimecard(USER_ID);

      setDashboard(dash);
      setTodayCard(today);
    }

    loadData();
  }, []);

  if (!dashboard) return <Layout>Loading...</Layout>;

  return (
    <Layout>
      <h1 className="text-3xl font-bold mb-6">Dashboard</h1>

      {/* Today status */}
      <div className="bg-white p-4 rounded shadow mb-6">
        <h2 className="text-xl font-semibold">Today's Status</h2>

        {dashboard.todaySubmitted ? (
          <p className="text-green-600 font-bold">
            Timecard submitted ✅
          </p>
        ) : (
          <p className="text-red-500 font-bold">
            Not submitted today ❌
          </p>
        )}
      </div>

      {/* Active streaks */}
      <div className="mb-6">
        <h2 className="text-xl font-semibold mb-3">
          Active Streaks 🔥
        </h2>

        <div className="grid md:grid-cols-3 gap-4">
          {Object.entries(dashboard.activeStreaks).map(
            ([habit, value]) => (
              <div
                key={habit}
                className="bg-white shadow rounded p-4"
              >
                <h3 className="capitalize text-lg font-semibold">
                  {habit}
                </h3>

                <p className="text-2xl font-bold text-blue-600">
                  {value}
                </p>
              </div>
            )
          )}
        </div>
      </div>

      {/* Longest streaks */}
      <div>
        <h2 className="text-xl font-semibold mb-3">
          Longest Streaks 🏆
        </h2>

        <div className="grid md:grid-cols-3 gap-4">
          {Object.entries(dashboard.longestStreaks).map(
            ([habit, value]) => (
              <div
                key={habit}
                className="bg-white shadow rounded p-4"
              >
                <h3 className="capitalize text-lg font-semibold">
                  {habit}
                </h3>

                <p className="text-2xl font-bold text-purple-600">
                  {value}
                </p>
              </div>
            )
          )}
        </div>
      </div>
    </Layout>
  );
}
import React from "react";
import { Link, useLocation } from "react-router-dom";

export default function Layout({ children }) {
  const location = useLocation();

  const navItemClass = (path) =>
    `p-2 rounded transition ${
      location.pathname === path
        ? "bg-gray-700"
        : "hover:bg-gray-700"
    }`;

  return (
    <div className="flex h-screen">

      {/* Sidebar */}
      <aside className="w-64 bg-gray-800 text-white p-5 flex flex-col">

        {/* App title */}
        <h2 className="text-2xl font-bold mb-6">
          Productivity App
        </h2>

        {/* Navigation */}
        <nav className="flex flex-col gap-2">

          <Link to="/dashboard" className={navItemClass("/dashboard")}>
            Dashboard
          </Link>

          <Link to="/user" className={navItemClass("/user")}>
            User Page
          </Link>

          {/* Future routes (enable later) */}

          {/*
          <Link to="/calendar" className={navItemClass("/calendar")}>
            Calendar
          </Link>

          <Link to="/analytics" className={navItemClass("/analytics")}>
            Analytics
          </Link>
          */}

        </nav>

        {/* Footer spacer */}
        <div className="flex-grow" />

        {/* Footer info */}
        <div className="text-sm text-gray-400">
          Built for consistency 📈
        </div>

      </aside>


      {/* Main content area */}
      <main className="flex-1 bg-gray-100 p-6 overflow-auto">

        {children}

      </main>

    </div>
  );
}
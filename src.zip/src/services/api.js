const BASE_URL = "http://localhost:8080";

export async function getDashboard(userId) {
  const res = await fetch(`${BASE_URL}/user/${userId}/dashboard`);
  return res.json();
}

export async function getStreaks(userId) {
  const res = await fetch(`${BASE_URL}/user/${userId}/streaks`);
  return res.json();
}

export async function getTodayTimecard(userId) {
  const res = await fetch(`${BASE_URL}/timecard/today/${userId}`);
  return res.json();
}

export async function getTimecardsBetween(userId, start, end) {
  const res = await fetch(
    `${BASE_URL}/timecard/${userId}?start=${start}&end=${end}`
  );

  return res.json();
}